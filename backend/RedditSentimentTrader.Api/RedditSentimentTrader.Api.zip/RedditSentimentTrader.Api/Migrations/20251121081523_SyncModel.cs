﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RedditSentimentTrader.Api.Migrations
{
    /// <inheritdoc />
    public partial class SyncModel : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ParentId",
                table: "RedditComments");

            migrationBuilder.DropColumn(
                name: "Permalink",
                table: "RedditComments");

            migrationBuilder.RenameColumn(
                name: "SourceThreadUrl",
                table: "RedditComments",
                newName: "ThreadUrl");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "ThreadUrl",
                table: "RedditComments",
                newName: "SourceThreadUrl");

            migrationBuilder.AddColumn<string>(
                name: "ParentId",
                table: "RedditComments",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Permalink",
                table: "RedditComments",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }
    }
}
