﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RedditSentimentTrader.Api.Migrations
{
    /// <inheritdoc />
    public partial class AddSentimentColumns : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<double>(
                name: "Confidence",
                table: "RedditComments",
                type: "float",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "SentimentLabel",
                table: "RedditComments",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<double>(
                name: "SentimentScore",
                table: "RedditComments",
                type: "float",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Confidence",
                table: "RedditComments");

            migrationBuilder.DropColumn(
                name: "SentimentLabel",
                table: "RedditComments");

            migrationBuilder.DropColumn(
                name: "SentimentScore",
                table: "RedditComments");
        }
    }
}
