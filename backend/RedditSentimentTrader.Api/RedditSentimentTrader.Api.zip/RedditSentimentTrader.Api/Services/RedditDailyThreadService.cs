﻿using RedditSentimentTrader.Api.Data;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;

namespace RedditSentimentTrader.Api.Services
{

    public interface IRedditDailyThreadService
    {
        Task<int> IngestThreadAsync(string threadUrl);
    }
   
public class RedditDailyThreadService : IRedditDailyThreadService
    {
        private readonly AppDbContext _db;
        private readonly IHttpClientFactory _clientFactory;
        private readonly IRedditAuthService _auth;

        public RedditDailyThreadService(AppDbContext db, IHttpClientFactory clientFactory, IRedditAuthService auth)
        {
            _db = db;
            _clientFactory = clientFactory;
            _auth = auth;
        }

        public async Task<int> IngestThreadAsync(string threadUrl)
        {
            var parts = threadUrl.Split('/');
            var threadId = parts.First(p => p.Length == 6);             
            var apiUrl = $"https://oauth.reddit.com/comments/{threadId}.json?depth=10&limit=500";

            var token = await _auth.GetValidAccessTokenAsync();

            var client = _clientFactory.CreateClient("RedditAPI");
            client.DefaultRequestHeaders.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

            
            var res = await client.GetAsync(apiUrl);
            res.EnsureSuccessStatusCode();

            var json = await res.Content.ReadAsStringAsync();
            using var doc = JsonDocument.Parse(json);

            var commentsArr = doc.RootElement[1].GetProperty("data")
                                          .GetProperty("children");

            var flat = new List<RedditComment>();
            foreach (var child in commentsArr.EnumerateArray())
                Flatten(child, flat, threadUrl);

            
            foreach (var c in flat)
            {
                bool exists = await _db.RedditComments.AnyAsync(x => x.RedditId == c.RedditId);
                if (!exists)
                    _db.RedditComments.Add(c);
            }

            await _db.SaveChangesAsync();
            return flat.Count;
        }

        private void Flatten(JsonElement element, List<RedditComment> output, string threadUrl)
        {
            if (element.GetProperty("kind").GetString() == "t1") 
            {
                var data = element.GetProperty("data");

                output.Add(new RedditComment
                {
                    RedditId = data.GetProperty("name").GetString() ?? "",
                    ParentId = data.GetProperty("parent_id").GetString() ?? "",
                    Author = data.GetProperty("author").GetString() ?? "[deleted]",
                    Body = data.GetProperty("body").GetString() ?? "",
                    Permalink = "https://reddit.com" + data.GetProperty("permalink").GetString(),
                    CreatedUtc = DateTimeOffset
                        .FromUnixTimeSeconds(data.GetProperty("created_utc").GetInt64())
                        .UtcDateTime,
                    SourceThreadUrl = threadUrl
                });

                
                if (data.TryGetProperty("replies", out var replies) &&
                    replies.ValueKind != JsonValueKind.String)
                {
                    var children = replies.GetProperty("data").GetProperty("children");
                    foreach (var r in children.EnumerateArray())
                        Flatten(r, output, threadUrl);
                }
            }
        }
    }


}
