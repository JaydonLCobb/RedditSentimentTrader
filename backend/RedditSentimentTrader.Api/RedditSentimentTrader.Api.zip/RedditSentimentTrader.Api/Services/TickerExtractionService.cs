﻿using System.Text.Json;
using OpenAI.Chat;

namespace RedditSentimentTrader.Api.Services
{
    public interface ITickerExtractionService
    {
        Task<TickerExtractionResult> ExtractAsync(string text);
    }

    public record TickerExtractionResult(
        bool IsMarketRelated,
        string? PrimaryTicker,
        List<string> Tickers
    );

    internal sealed class TickerExtractionDto
    {
        public bool IsMarketRelated { get; set; }
        public string? PrimaryTicker { get; set; }
        public List<string> Tickers { get; set; } = new();
    }

    public class OpenAiTickerExtractionService : ITickerExtractionService
    {
        private readonly ChatClient _chat;

        public OpenAiTickerExtractionService(ChatClient chat)
        {
            _chat = chat;
        }

        public async Task<TickerExtractionResult> ExtractAsync(string text)
        {
            var messages = new List<ChatMessage>
            {
                new SystemChatMessage(
                    "You extract stock tickers from casual Reddit comments. " +
                    "Map company names or nicknames to their primary US stock ticker. " +
                    "Examples:\n" +
                    "\"NVIDIA to the moon\" -> NVDA\n" +
                    "\"buy Google\" -> GOOGL\n" +
                    "\"Meta calls\" -> META\n" +
                    "\"apple and tesla\" -> AAPL, TSLA\n" +
                    "If the comment is not about markets or no ticker is clear, mark is_market_related=false."
                ),
                new UserChatMessage($"Comment: \"{text}\"")
            };

            var options = new ChatCompletionOptions
            {
                ResponseFormat = ChatResponseFormat.CreateJsonSchemaFormat(
                    jsonSchemaFormatName: "ticker_extraction",
                    jsonSchema: BinaryData.FromString("""
                    {
                      "type": "object",
                      "properties": {
                        "is_market_related": { "type": "boolean" },
                        "primary_ticker": {
                          "type": ["string","null"],
                          "description": "Main ticker this comment is about, e.g., NVDA, TSLA"
                        },
                        "tickers": {
                          "type": "array",
                          "items": { "type": "string" }
                        }
                      },
                      "required": ["is_market_related","primary_ticker","tickers"],
                      "additionalProperties": false
                    }
                    """),
                    jsonSchemaIsStrict: true)
            };

            ChatCompletion completion = await _chat.CompleteChatAsync(messages, options);
            string json = completion.Content[0].Text;

            var dto = JsonSerializer.Deserialize<TickerExtractionDto>(
                json,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true }
            ) ?? throw new InvalidOperationException($"Failed to parse ticker JSON: {json}");

            // Normalize tickers (strip $, upper, map common names)
            string? primary = NormalizeTicker(dto.PrimaryTicker);
            var all = dto.Tickers
                .Select(NormalizeTicker)
                .Where(t => t is not null)
                .Distinct()
                .ToList()!;

            return new TickerExtractionResult(dto.IsMarketRelated, primary, all);
        }

        private static string? NormalizeTicker(string? raw)
        {
            if (string.IsNullOrWhiteSpace(raw)) return null;

            var t = raw.Trim();

            // strip leading $ / # etc
            if (t.StartsWith("$") || t.StartsWith("#"))
                t = t[1..];

            t = t.Trim().ToUpperInvariant();

            // map common names -> tickers
            return t switch
            {
                "NVIDIA" => "NVDA",
                "NVDA" => "NVDA",

                "GOOGLE" => "GOOGL",
                "ALPHABET" => "GOOGL",

                "FACEBOOK" => "META",
                "META PLATFORMS" => "META",

                "TESLA" => "TSLA",
                "APPLE" => "AAPL",

                _ => t // fallback: assume it's already a ticker
            };
        }
    }
}
