﻿namespace HtmlAgilityPack
{
    internal class HtmlDocument
    {
        public HtmlDocument()
        {
        }
    }
}